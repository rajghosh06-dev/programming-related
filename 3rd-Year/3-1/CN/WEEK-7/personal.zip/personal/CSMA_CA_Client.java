// Week-7
// CSMA-CA Client
package personal;

import java.io.*;
import java.net.*;
import java.util.Random;

public class CSMA_CA_Client {
    private static final String HOST = "localhost";
    private static final int PORT = 5000;
    private static final int IFS = 1000;       // 1 second Inter-Frame Space
    private static final int SLOT_TIME = 200;  // 200 ms slot time
    private static final int MAX_ATTEMPTS = 15;

    public static void main(String[] args) {
        System.out.println("=== CSMA/CA Client Started ===");
        Random rand = new Random();

        for (int k = 1; k <= MAX_ATTEMPTS; k++) {
            System.out.println("\n[Attempt " + k + "]");

            // Step 1: Check if channel is idle
            System.out.println("Sensing channel...");
            if (!isChannelIdle()) {
                System.out.println("Channel busy. Retrying...");
                continue;
            }

            // Step 2: Wait IFS
            System.out.println("Channel idle. Waiting IFS (" + IFS + " ms)...");
            sleep(IFS);

            // Step 3: Check if still idle
            if (!isChannelIdle()) {
                System.out.println("Channel became busy during IFS.");
                continue;
            }

            // Step 4: Backoff procedure
            int maxRange = (int) Math.pow(2, Math.min(k, 10)) - 1;
            int r = rand.nextInt(maxRange + 1);
            System.out.println("Channel still idle. Random slot R = " + r);
            System.out.println("Waiting backoff time: " + (r * SLOT_TIME) + " ms");
            sleep(r * SLOT_TIME);

            // Step 5: Send frame and receive ACK
            if (sendFrameAndCheckAck("Hello Server - Frame " + k)) {
                System.out.println("ACK received! Transmission successful.");
                return;
            } else {
                System.out.println("ACK not received (timeout/error).");
            }
        }
        System.out.println("Transmission failed after maximum attempts.");
    }

    // Simulates channel sensing (available if server is reachable)
    private static boolean isChannelIdle() {
        try (Socket s = new Socket(HOST, PORT)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static boolean sendFrameAndCheckAck(String message) {
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            
            socket.setSoTimeout(3000); // 3-second ACK timeout
            out.println(message);
            System.out.println("Frame sent: " + message);

            String ack = in.readLine();
            return "ACK".equalsIgnoreCase(ack);
        } catch (IOException e) {
            return false;
        }
    }

    private static void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}