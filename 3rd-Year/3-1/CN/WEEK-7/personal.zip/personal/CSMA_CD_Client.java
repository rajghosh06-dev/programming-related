// Week-7
// CSMA-CD Client

package personal;

import java.io.*;
import java.net.*;
import java.util.Random;

public class CSMA_CD_Client {
    private static final String HOST = "localhost";
    private static final int PORT = 5000;
    private static final int TP = 500; // Slot time (0.5s for fast demonstration)
    private static final int MAX_ATTEMPTS = 15;

    public static void main(String[] args) {
        System.out.println("=== CSMA/CD Client Started ===");
        Random rand = new Random();

        for (int k = 1; k <= MAX_ATTEMPTS; k++) {
            System.out.println("\nAttempt " + k + ": Trying to transmit...");
            if (sendData("CNLABS - Frame Data")) {
                System.out.println("Transmission successful!");
                return;
            }

            // Binary Exponential Backoff: R in [0, 2^k - 1]
            int maxRange = (int) Math.pow(2, Math.min(k, 10)) - 1;
            int r = rand.nextInt(maxRange + 1);
            int tb = r * TP;

            System.out.println("Collision detected! Chosen backoff slot R = " + r);
            System.out.println("Waiting backoff time: " + tb + " ms");
            try {
                Thread.sleep(tb);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("Transmission failed after maximum attempts.");
    }

    private static boolean sendData(String message) {
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            out.println(message);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}